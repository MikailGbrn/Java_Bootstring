package com.belajar.spring;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class BelajarApiLatihanApplication {

	public static void main(String[] args) {
		SpringApplication.run(BelajarApiLatihanApplication.class, args);
	}

}
