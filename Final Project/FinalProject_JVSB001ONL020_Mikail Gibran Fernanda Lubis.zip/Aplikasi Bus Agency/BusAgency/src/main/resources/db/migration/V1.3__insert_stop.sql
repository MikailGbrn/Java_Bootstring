insert into stop values
(1, '1-2', 'Teluk', 'Karang'),
(2, '1-8', 'Cimeng', 'Sukaraja 1-8'),
(3, '1-3', 'Raja BasaI', 'Kedaton 1-3'),
(4, '1-2', 'Sukabumi', 'Sukarame 1-2'),
(5, '1-10', 'Tanjung Senang', 'Jati Agung 1-10');