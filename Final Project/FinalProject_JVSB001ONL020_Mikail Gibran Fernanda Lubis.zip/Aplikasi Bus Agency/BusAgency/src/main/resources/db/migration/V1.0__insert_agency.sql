INSERT INTO `agency`(`code`, `details`, `name`, `owner_user_id`)
VALUES ("BDL","PT Angkasa Muda","Angkot Karang",1);