public class LuasLingkaran {
    public static void main(String[] args) {
        double Pi, luas;
        int r;

        Pi = 3.14;
        r = 18;

        luas = Pi * r * r;

        System.out.println("Luas Lingkaran dengan jari-jari " + r + " adalah " + luas);
    }
}
