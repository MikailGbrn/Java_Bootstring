public class PerbandinganTrueFalse {
    public static void main(String[] args) {
        int a = 10;
        int b = 8;
        int c = 12;
        int d = 5;

        System.out.println("Test ke - 1 : " + (a > b));
        System.out.println("Test ke - 2 : " + (d < c));
        System.out.println("Test ke - 3 : " + (c >= b));
        System.out.println("Test ke - 4 : " + (d <= b));
        System.out.println("Test ke - 5 : " + (a == a));
        System.out.println("Test ke - 6 : " + (a != b));
        System.out.println("Test ke - 7 : " + (d > b));
        System.out.println("Test ke - 8 : " + (a <= d));
        System.out.println("Test ke - 9 : " + (c == b));
        System.out.println("Test ke - 10 : " + (b != b));
    }
}
