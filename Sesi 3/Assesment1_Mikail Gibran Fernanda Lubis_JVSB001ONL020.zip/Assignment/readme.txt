Nama: Mikail Gibran Fernanda Lubis
Kode Peserta: JVSB001ONL020
Panduan Penggunaan Aplikasi:

-- App Required --

1. Visual Studio Code 1.68.0
2. Eclipse 2022
3. JDK 17
4. JDK 8u202

-- Extension Needed --
1. Visual Studio Code 1.68.0:
	- Code Runner
	- Springboot Tools
	- Springboot Extension
	- Springboot Snipets
	- Java Extension Package
	- Prettier Code
	- Maven 
2. Eclipse IDE 2022:
	- Maven Depedency
	- Maven Java
	- Java 18 Support for eclipse 2022-03
	- Eclipse Web Developer Tools 3.25
	- Springboot Tools 4

-- Start The Project --

1. Install JDK 17 and JDK 8
2. Creat Path Directory dari JDK 17
3. Config dan pastikan java dapat berjalan ketika dipanggil di cmd
4. Jalankan code di visual studio code

